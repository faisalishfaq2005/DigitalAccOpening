﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.BL
{
    public class CustomerMoreInfo
    {
        public CustomerMoreInfo(string name,string fatherName,DateTime dobs,string placeofBirth,DateTime cdoi,DateTime cdox,string g, string maritalstatus,string rel) 
        {
            Name = name;
            FatherName = fatherName;
            dob = dobs;
            placeOfBirth = placeofBirth;
            cnicdateofissuence = cdoi;
            cnicdateofexpiry=cdox;
            gender = g;
            maritalStatus= maritalstatus;
            relegion = rel;




        }
        public string Name;
        public string FatherName;
        public DateTime dob;
        public string placeOfBirth;
        public DateTime cnicdateofissuence;
        public DateTime cnicdateofexpiry;
        public string gender;
        public string maritalStatus;
        public string relegion;
    }
}

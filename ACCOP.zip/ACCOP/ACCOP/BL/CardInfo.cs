﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.BL
{
    public class CardInfo
    {
        public CardInfo(int cardtype,string nameOnCard) 
        {
            CardType=cardtype;
            NameOnCard=nameOnCard;

        }
        public int CardType;
        public string NameOnCard;
    }
}

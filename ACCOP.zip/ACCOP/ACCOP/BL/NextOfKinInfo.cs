﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.BL
{
    public class NextOfKinInfo
    {
        public string RelationName;
        public string Cnic;
        public string PhoneNumber;
        public string Relation;
    }
}

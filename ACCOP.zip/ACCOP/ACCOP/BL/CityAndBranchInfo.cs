﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.BL
{
    public class CityAndBranchInfo
    {
        public CityAndBranchInfo(string preferedCity,string preferedBranch) 
        {
            PreferedCity=preferedCity;

            PreferedBranch=preferedBranch;
        }
        public string PreferedCity;
        public string PreferedBranch;

    }
}

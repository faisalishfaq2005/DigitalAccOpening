﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.BL
{
    public class CustomerStartingInfo
    {

        public CustomerStartingInfo() { }

        private string Cnic;
        private string PhoneNumber;
        private string gmail;
        private string PakistaniNational;
        private string MotherName;
        
        private string TypeOfBanking;
        //add type of account and purpose of account

        public string getCnic()
        { return Cnic; }

        public string getPhoneNum()
        { return PhoneNumber; }

        public string getEmail()
        { return gmail; }

        public string getPakistaniNational()
        { return PakistaniNational; }
        public string getMotherName() {  return MotherName; }

        

        public string getTypeOfBanking()
        { return TypeOfBanking; }

        

        //setters

        public void setCnic(string cnic)
        {
            Cnic = cnic;
        }

        public void setPhoneNumber(string phone)
        {
            PhoneNumber=phone;
        }

        public void setGmail(string g)
        {
            gmail = g;
        }
        public void setPakistaniNational(string b)
        {
           PakistaniNational=b;
        }
        public void setMotherName(string n)
        {
            MotherName = n;
        }
        
        public void setTypeOfBanking(string t)
        {
            TypeOfBanking=t;
        }
        




    }
    
    
}

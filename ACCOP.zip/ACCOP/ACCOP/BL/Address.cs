﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.BL
{
    public class Address
    {
        public Address(string address,string city,string province,string postalcode)
        {
            Addres = address;
            City= city;
            Province= province;
            PostalCode= postalcode;
            
        }
        public string Addres;
        public string City;
        public string Province;
        public string PostalCode;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.DLInterfaces
{
    public interface ICustomerStartingInfoDL
    {
        string retreive();
    }
}

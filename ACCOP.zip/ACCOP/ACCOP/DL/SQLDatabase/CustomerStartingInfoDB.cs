﻿using ACCOP.DLInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACCOP.DL.SQLDatabase
{
    public class CustomerStartingInfoDB:ICustomerStartingInfoDL
    {
        public string retreive()
        {
            return "rtr";
        }

    }
}
